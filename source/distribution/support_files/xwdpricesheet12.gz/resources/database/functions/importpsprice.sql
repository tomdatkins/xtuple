-- Function: xwdpricesheet.importpsprice(text, text)

-- DROP FUNCTION xwdpricesheet.importpsprice(text, text);

CREATE OR REPLACE FUNCTION xwdpricesheet.importpsprice(pprovider text, pmode text)
  RETURNS integer AS
$BODY$
-- Copyright (c) 1999-2012 by OpenMFG LLC, d/b/a xTuple. 
-- See www.xtuple.com/CPAL for the full text of the software license.
DECLARE
  _c RECORD;
  _kount INTEGER := 0;
  _result INTEGER;

BEGIN

  RAISE NOTICE 'importpsPrice starting with pProvider=%, pMode=%', pProvider, pMode;
  SELECT count(*) FROM xwdpricesheet.psprice INTO _kount;
  RAISE NOTICE 'importpsPrice importing % records', _kount;

  SELECT * INTO _c FROM xwd.catconfig WHERE (catconfig_provider=pProvider);
  IF (NOT FOUND) THEN
    RAISE EXCEPTION 'Provider % not configured', pProvider;
  END IF;

  RAISE NOTICE 'importpsPrice starting deleting from catalog';
  IF (pMode = 'L') THEN
    DELETE FROM xwd.catalog WHERE (catalog_provider=pProvider);
  ELSE    DELETE FROM xwd.catalog WHERE (catalog_provider=pProvider) AND
                                  (catalog_mfr_cat_num IN (SELECT (psprice_mfr_cat_num)
                                                        FROM xwdpricesheet.psprice)) and (catalog_mfr_shortname IN (SELECT (psprice_vend_num)
                                                        FROM xwdpricesheet.psprice)) ;
  END IF;
  RAISE NOTICE 'importpsPrice finished deleting from catalog';

  RAISE NOTICE 'importpsPrice starting inserting into catalog';
  INSERT INTO xwd.catalog
(catalog_provider ,
 catalog_mfr_ucc_num ,
 catalog_mfr_shortname ,
 catalog_mfr_fullname ,
 catalog_ps_min_order_type ,
 catalog_ps_min_order ,
 catalog_i2_cat_num,
 catalog_mfr_cat_num ,
 catalog_product_name ,
 catalog_mfr_description ,
 catalog_comm_code ,
 catalog_ps_lgcy_uom ,
 catalog_ps_uom ,
 catalog_list ,
 catalog_col3 ,
 catalog_cost ,
 catalog_custom_price1 ,
 catalog_pkg_weight ,
 catalog_pkg_qty ,
 catalog_pkg_uom ,
 catalog_2k_desc ,
 catalog_indv_weight ,
 catalog_pkg_freight_class ,
 catalog_upc ,
 catalog_product_category,
 catalog_price_src_name ,
 catalog_ps_dscnt_schd_code ,
 catalog_pdf_url ,
 catalog_web_url )
SELECT
 'PS',
 psprice_vend_num ,
 psprice_mfr_shortname ,
 psprice_mfr_fullname ,
 psprice_min_order_type,
 xwd.convToNum(psprice_min_order) ,
 psprice_i2_cat_num ,
 psprice_mfr_cat_num ,
 psprice_product_name ,
 psprice_mfr_descrip ,
 psprice_comm_code ,
 psprice_lgcy_uom ,
 psprice_uom ,
 round((xwd.convToNum(psprice_list)/ xwd.convToNum(psprice_uom_qty)), 4) ,
    round((xwd.convToNum(psprice_col3)/ xwd.convToNum(psprice_uom_qty)),4),
    round((xwd.convToNum(psprice_cost)/ xwd.convToNum(psprice_uom_qty)),4) ,
    round((xwd.convToNum(psprice_custom_price1)/xwd.convToNum(psprice_uom_qty)),4) ,
    round(xwd.convToNum(psprice_pkg_weight),4) ,
    round(xwd.convToNum(psprice_pkg_qty),4) ,
 psprice_pkg_uom ,
 psprice_2k_desc ,
 xwd.convToNum (psprice_indv_weight) ,
 psprice_pkg_freight_class ,
 psprice_upc ,
 psprice_prod_cat ,
 psprice_price_src_name ,
 psprice_dscnt_schd_code ,
 psprice_pdf_url ,
 psprice_web_url 
  FROM xwdpricesheet.psprice;
  RAISE NOTICE 'importpsPrice starting inserting into catalog';

  SELECT xwdpricesheet.updateCatalogps(pProvider) INTO _result;

  RAISE NOTICE 'importPricesvc completed';
  RETURN _result;
END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION xwdpricesheet.importpsprice(text, text)
  OWNER TO admin;
