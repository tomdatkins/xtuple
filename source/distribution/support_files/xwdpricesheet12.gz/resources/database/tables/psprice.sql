CREATE TABLE xwdpricesheet.psprice(
psprice_id  SERIAL NOT NULL,
psprice_vend_num text,
psprice_mfr_shortname text,
psprice_mfr_fullname text,
psprice_min_order_type text,
psprice_min_order text,
psprice_i2_cat_num text,
psprice_mfr_cat_num text,
psprice_product_name text,
psprice_mfr_descrip text,
psprice_comm_code text,
psprice_comm_pik text,
psprice_lgcy_uom text,
psprice_uom text,
psprice_uom_qty text DEFAULT '1',
psprice_list text,
psprice_col3 text,
psprice_cost text,
psprice_custom_price1 text,
psprice_pkg_weight text,
psprice_pkg_qty text,
psprice_pkg_uom text,
psprice_2k_desc text,
psprice_indv_weight text,
psprice_pkg_freight_class text,
psprice_upc text,
psprice_prod_cat text,
psprice_price_src_name text,
psprice_dscnt_schd_code text,
psprice_pdf_url text,
psprice_web_url text
);
ALTER TABLE xwdpricesheet.psprice OWNER TO "admin";
GRANT ALL ON TABLE xwdpricesheet.psprice TO "admin";
GRANT ALL ON TABLE xwdpricesheet.psprice TO xtrole;
GRANT ALL ON SEQUENCE xwdpricesheet.psprice_psprice_id_seq TO xtrole;

COMMENT ON TABLE xwdpricesheet.psprice IS 'ps pricing';

