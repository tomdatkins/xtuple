/* Add new Quality comment types */
SELECT xt.add_comment_type('Quality', 'QPLAN', 'Quality Plans');
SELECT xt.add_comment_type('Quality', 'QTEST', 'Quality Tests');

